import React from 'react';
import Sidebar from './components/Sidebar'; // Assuming this is in a separate file
import Header from './components/Header'; // Assuming this is in a separate file
import Dashboard from './components/Dashboard'; // Assuming this is in a separate file
import './styles/layout.css';
import './styles/components.css';
import './App.css';

function App() {
  return (
    <div className="app-container">
      <Sidebar />
      <div className="main-content-area">
        <Header />
        <Dashboard />
      </div>
    </div>
  );
}

export default App;